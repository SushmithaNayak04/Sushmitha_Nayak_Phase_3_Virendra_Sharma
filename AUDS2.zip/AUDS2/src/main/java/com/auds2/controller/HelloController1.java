package com.auds2.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
	public class HelloController1 {
	@RequestMapping("/add")
		public String display()
		{
			return "viewpage1";
		}	
	}
