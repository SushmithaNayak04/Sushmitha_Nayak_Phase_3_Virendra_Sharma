package com.auds2.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloController4 {
	@RequestMapping("/select")
	public String display()
	{
		return "viewpage4";
	}	
}






	
