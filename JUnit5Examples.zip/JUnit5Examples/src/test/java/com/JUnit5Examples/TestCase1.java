package com.JUnit5Examples;
import org.junit.jupiter.api.Test;
public class TestCase1 {
	 
    @BeforeAll
    public static void brforeall() {
        System.out.println("Starting project");
    }
     
    @BeforeEach
    public void beforeeach() {
    	System.out.println("calling method");
    }
     
    @Test
    public void testAdd() {
        // test method
    }
     
    @Test
    public void testSubtract() {
        // test method
    }
     
    @AfterEach
    public void tearDown() {
        // code executed after each test method
    }
     
    @AfterAll
    public static void tearDownClass() {
        // code executed after all test methods
    }